MIGHTY ASSETS — Website starter

FILES
- index.html: responsive dark purple/black creator resource website.

PREVIEW
- Open index.html in Chrome, Edge, Firefox or Safari.
- Search and category filters work.
- The upload form accepts images and MP4 video and previews them in the current browser session.

IMPORTANT UPLOAD NOTE
This is a static front-end starter. Browser previews use temporary object URLs, so uploaded files are not permanently stored and are not shared with other visitors. To make this a public asset-download website, add a backend and cloud file storage (such as Supabase Storage or Firebase Storage), then connect the upload form to it. Do not publish private or copyrighted clips without permission.

PUBLISH
1. Upload index.html to a static host such as Netlify, Cloudflare Pages or GitHub Pages.
2. For permanent public uploads, connect a storage/database service and add authentication/admin upload permissions.
